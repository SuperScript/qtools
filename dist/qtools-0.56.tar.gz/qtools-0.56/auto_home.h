#ifndef AUTO_HOME_H
#define AUTO_HOME_H

extern char auto_home[];

#endif
