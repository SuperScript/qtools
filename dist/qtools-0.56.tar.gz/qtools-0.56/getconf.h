#ifndef GETCONF_H
#define GETCONF_H

extern int getconf(stralloc *,char *,int,char *,char *);
extern int getconf_line(stralloc *,char *,int,char *,char *);

#endif
