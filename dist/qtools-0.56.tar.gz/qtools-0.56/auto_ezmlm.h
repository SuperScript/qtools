#ifndef AUTO_EZMLM_H
#define AUTO_EZMLM_H

extern char auto_ezmlm[];

#endif
